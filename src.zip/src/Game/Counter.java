package Game;

public class Counter {
    private int count;

    public Counter() {
        count = 0;
    }

    public void increase(int number) {
        count += number;
    }

    public void decrease(int number) {
        count -= number;
    }

    public int getValue() {
        return count;
    }
}

