package Game;

import Srite.Ball;
import Srite.Block;

public class ScoreTrackingListener extends Counter implements HitListener {
    private Counter currentScore;

    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }

    public void hitEvent(Block beingHit, Ball hitter) {
        currentScore.increase(5);
    }
}