package Game;

import Srite.Ball;
import Srite.Block;

public class PrintingHitListener implements HitListener {
    public void hitEvent(Block beingHit, Ball hitter) {
    }
}

