package Game;

import Srite.Sprite;
import biuoop.DrawSurface;

public class ScoreIndicator implements Sprite {
    Counter score;

    public ScoreIndicator(Counter score) {
        this.score = score;
    }

    @Override
    public void drawOn(DrawSurface d) {
        d.drawRectangle(0,0, 800, 20);
        d.drawText(370, 15, "Score: "+ score.getValue(), 18);
    }

    @Override
    public void timePassed() {
    }

    @Override
    public void addToGame(Game g) {
        g.addSprite(this);
    }
}
