package Game;

import Srite.Ball;
import Srite.Block;

public class BallRemover implements HitListener {
    private Game game;
    private Counter remainingBalls;

    public BallRemover(Game game, Counter remainingBalls) {
        this.game = game;
        this.remainingBalls = remainingBalls;
    }
    public void hitEvent(Block beingHit, Ball hitter){
        this.remainingBalls.decrease(1);
        this.game.removeSprite(hitter);
    }
}
