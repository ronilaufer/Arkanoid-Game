package Collision;

import Srite.Ball;
import Geometry.Point;
import Geometry.Rectangle;

/**
 * The {@code Collidable} interface should be implemented by any object
 * that can be collided with (e.g., blocks, walls, paddles).
 *
 * <p>
 * It defines methods for retrieving the collision boundary and
 * responding to collision events by updating the velocity of the object
 * that hit it.
 * </p>
 */
public interface Collidable {
    // Return the "collision shape" of the object.
    /**
     * Returns the "collision shape" of the object.
     * This shape is used to detect collisions with other objects (typically a {@link Ball}).
     *
     * @return the {@link Rectangle} that defines the shape of the object for collision detection
     */
    Rectangle getCollisionRectangle();

    // Notify the object that we collided with it at collisionPoint with
    // a given velocity.
    // The return is the new velocity expected after the hit (based on
    // the force the object inflicted on us).
    /**
     * Notifies the object that a collision occurred at the specified point with a given velocity.
     * The method returns the new velocity of the object that hit this collidable,
     * after taking into account the effects of the collision (like bouncing).
     *
     * @param collisionPoint  the point at which the collision occurred
     * @param currentVelocity the velocity of the object before the collision
     * @return the new velocity of the object after the collision
     */
    Velocity hit(Ball hitter ,Point collisionPoint, Velocity currentVelocity);
}

